EMAF205 Landing
===============

A minimal FTP-first landing page for offers, workshops, launches and small projects.

Created by EmaF205
Generative AI professor in Milan
https://linktr.ee/emaf205
Contact: emagumroad@gmail.com


WHAT IT IS
----------

EMAF205 Landing is a small landing page system made for people who want to publish a clear page without a database, admin panel or build step.

It is designed for:

- workshops
- services
- events
- product launches
- digital downloads
- small independent projects


FILES
-----

Required runtime files:

- index.php
- page.txt
- style.txt

Optional advanced file:

- custom.css


HOW TO USE
----------

1. Open page.txt.
2. Replace the sample text with your real offer.
3. Open style.txt if you want to change colors or font.
4. Upload the files to your web server with FTP.
5. Open the folder URL in a browser.

Example:

/public_html/my-landing/
  index.php
  page.txt
  style.txt
  custom.css


CONTENT STRUCTURE
-----------------

page.txt controls the landing content.

Main fields:

- SITE_TITLE
- SITE_DESCRIPTION
- EYEBROW
- HERO_TITLE
- HERO_TEXT
- CTA_TEXT
- CTA_URL
- CTA_TARGET

Repeated blocks:

- POINT
- STEP
- DETAIL

Final call to action:

- FINAL_TITLE
- FINAL_TEXT
- FINAL_CTA_TEXT
- FINAL_CTA_URL
- FINAL_CTA_TARGET

Footer:

- FOOTER_TEXT


OPTIONAL SECTIONS
-----------------

The structure is fixed but intelligent.

If a POINT, STEP, DETAIL, FINAL CTA or FOOTER section is empty, it is not shown.

This keeps the tool simple:

page.txt  = content and optional sections
style.txt = colors and font
index.php = engine, do not edit


STYLE
-----

style.txt controls:

- BACKGROUND_COLOR
- TEXT_COLOR
- MUTED_TEXT_COLOR
- FONT
- BUTTON_BACKGROUND
- BUTTON_TEXT_COLOR
- BUTTON_BORDER_COLOR
- LINE_COLOR

FONT supports:

- serif
- sans


CUSTOM CSS
----------

custom.css is optional and advanced.

If custom.css exists next to index.php, it is loaded automatically after the default style.

Use it only if you want to override the layout manually.


SECURITY NOTES
--------------

The tool escapes page content before rendering it.

Unsafe URL schemes such as javascript:, data: and vbscript: are blocked.

Only simple HEX colors are accepted in style.txt.


REQUIREMENTS
------------

- PHP 8 or newer recommended
- No database
- No admin panel
- No build step
- FTP upload supported


PROJECT PHILOSOPHY
------------------

Small.
Readable.
Portable.
Independent.

Made by EmaF205 as part of a minimal FTP-first tool family.

A project by EmaF205
Made with ♥ in Milan
https://linktr.ee/emaf205
